Sound class plays WAV only with the following characteristics
16-bit dynamic range
8K hertz sample rate
normalized audio

The following site will generate WAV with these parameters:
http://audio.online-convert.com/convert-to-wav